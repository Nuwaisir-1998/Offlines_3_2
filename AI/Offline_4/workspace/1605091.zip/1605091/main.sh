g++ -O2 main.cpp -o main
./main.exe