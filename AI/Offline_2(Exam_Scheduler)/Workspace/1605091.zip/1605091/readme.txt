1605091.cpp is the source code
summary.csv contains the output informations for all the given inputs (13 in total)
The code reads the number of test cases and then reads strings from the file named in, and those strings are the name of the files, first the crs file, and then the stu file. A sample input is given. The input files should be kept inside the inputs folder.
The .sol file generates inside the outputs folder.
To execute the program, please run the 1605091.sh file. (Command: bash 1605091.sh for Linux, sh 1605091.sh for Windows)