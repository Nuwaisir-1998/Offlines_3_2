#include <bits/stdc++.h>

#include <ext/pb_ds/assoc_container.hpp> 
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/numeric>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

using namespace std::chrono; 
  
#define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 

typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<ll, ll> pll;
typedef pair<int, int> pii;
typedef vector<pll> vpll;

#define all(x) (x).begin(), (x).end()
#define MOD 1000000007
#define PI acos(-1)
#define MAXN 200005
#define INF 1000000000000000000
#define nl '\n'
#define MAX(x) *max_element(all(x))
#define MIN(x) *min_element(all(x))




#define ALL_PAIR_COUNT 250
#define HILL_CLIMBING_COUNT 100000




template <typename T>
void printv(vector<T> &v){for (auto e : v) cout << e << ' ';cout << '\n';}

struct custom_hash {
    // to make unordered map safe
    static uint64_t splitmix64(uint64_t x) {
        // http://xorshift.di.unimi.it/splitmix64.c
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    size_t operator()(uint64_t x) const {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

unordered_map<ll, ll, custom_hash> safe_map;
gp_hash_table<ll, ll, custom_hash> safe_hash_table;

ofstream ofs("out.csv");

class Graph
{
    public:
    // considering 0 indexing
    int V;
    int n_stu;
    int total_kempe_count;
    double initial_penalty;
    double total_time;
    string input_name;
    string scheme_name;
    vector<unordered_set<int>> adj;
    vector<int> color;
    vector<vector<int>> student_courses;
    vector<vector<int>> weight;
    vector<vector<int>> total_weight;
    vector<vector<int>> kempe_done;
    unordered_set<int> vis;
    vector<int> saturation;
    vector<bool> mark;
    unordered_set<int> track_subgraphs;
    // set<pii> kempe_edges;
    double total_penalty;
    Graph(int V){
        init(V);
    }

    void init(int n){
        total_kempe_count = 0;
        track_subgraphs.clear();
        n_stu = 0;
        total_penalty = 0;
        this -> V = n;
        adj.resize(n);
        vis.clear();
        // kempe_edges.clear();
        mark.resize(n);
        color.resize(n);
        saturation.resize(n);
        fill(color.begin(), color.end(), -1);
        weight.resize(n+1);
        for(int i=0;i<n+1;i++) weight[i].resize(n+1);
        total_weight.resize(n+1);
        for(int i=0;i<n+1;i++) total_weight[i].resize(n+1);
        kempe_done.resize(n+1);
        for(int i=0;i<n+1;i++) kempe_done[i].resize(n+1);
    }

    void add_student_with_courses(vector<int> courses){
        student_courses.push_back(courses);
        n_stu++;
    }

    void addEdge(int u, int v){
        if(v >= V or u >= V or v < 0 or u < 0){
            cout << "can't add edge (" << u << ", " << v << ")\n";
            return;
        }
        adj[u].insert(v);
        adj[v].insert(u);
        weight[u][v]++;
        weight[v][u]++;
    }

    void print(){
        int tot_edges = 0;
        cout << "Total vertices : " << V << "\n";
        // cout << "adj:\n";
        int mx = 0;
        for(int i=0;i<V;i++){
            // cout << i << ": ";
            tot_edges += adj[i].size();
            // for(auto ele : adj[i]){
            //     cout << ele << " ";
            // }
            // cout << "\n";
            mx = max(mx, (int)adj[i].size());
        }
        cout << "Total edges : " << tot_edges << "\n";
        cout << "Max degree: ";
        cout << mx << "\n";
        cout << "student_courses:\n";
        for(int i=0;i<student_courses.size();i++){
            cout << i << ": ";
            printv(student_courses[i]);
        }
        
        cout << "color:\n";
        printv(color);

        cout  << "color of neighbours:\n";
        for(int i=0;i<student_courses.size();i++){
            cout << i << ": ";
            for(auto ele : student_courses[i]){
                cout << color[ele] << " ";
                // cout << ele << " ";
            }
            cout << "\n";
        }
        for(int i=0;i<V;i++){
            for(int j=0;j<V;j++){
                cout << "(" << i << "," << j << ") : " << weight[i][j] << "\n";
            }
        }
    }

    int MEX(int u){
        unordered_set<int> ust;
        for(auto ele : adj[u]){
            ust.insert(color[ele]);
        }
        for(int i=0;i<V;i++){
            if(ust.find(i) == ust.end()){
                return i;
            }
        }
    }

    int calculate_slots_cnt(){
        unordered_set<int> st;
        for(int i=0;i<V;i++){
            if(color[i] == -1){
                cout << "vertex " << i << " is still uncolored.\n";
            }else
                st.insert(color[i]);
        }
        return (int)st.size();
    }

    vector<int> get_highest_degree_ordering() {
        vector<pii> vp;
        for(int i=0;i<V;i++){
            vp.push_back({(int)adj[i].size(), i});
        }
        sort(vp.begin(), vp.end(), greater<pii>());
        vector<int> order(V);
        for(int i=0;i<V;i++) order[i] = vp[i].second;
        return order;
    }

    void calculate_saturation(){    /// needs unit testing
        for(int i=0;i<V;i++){
            unordered_set<int> ust;
            for(auto ele : adj[i]){
                if(color[ele] != -1){
                    ust.insert(color[ele]);
                }
            }
            saturation[i] = (int)ust.size();
        }
    }

    void fix_saturation(int v){
        unordered_set<int> ust;
        for(auto ele : adj[v]){
            if(color[ele] != -1){
                ust.insert(color[ele]);
            }
        }
        saturation[v] = (int)ust.size();
    }

    int get_max_sat_deg(){
        tuple<int,int,int> mx = {-1, -1, -1};
        for(int i=0;i<V;i++){
            tuple<int,int,int> t = {saturation[i], (int)adj[i].size(), i};
            if(color[get<2>(t)] == -1)
                mx = max(mx, t);
        }
        return get<2>(mx);
    }

    int get_uncolored(){
        for(int i=0;i<V;i++){
            if(color[i] == -1) return i;
        }
        return -1;
    }

    int penalty(int dif){
        if(dif > 5) return 0;
        return power(2, 5 - dif);
    }

    double calculate_total_penalty(){
        total_penalty = 0;
        int n_stu = student_courses.size();
        for(int i=0;i<V;i++){
            for(auto ele : adj[i]){
                total_weight[i][ele] = weight[i][ele] * penalty(abs(color[ele] - color[i]));
                total_penalty += total_weight[i][ele];
            }
        }
        total_penalty /= 2;
        return total_penalty / n_stu;
    }

    void dfsVis(int s, int c1, int c2){
        track_subgraphs.insert(s);
        vis.insert(s);
        mark[s] = true;
        if(color[s] == c1) color[s] = c2;
        else color[s] = c1;
        for(auto ele : adj[s]){
            if(vis.find(ele) == vis.end() and (color[ele] == c1 or color[ele] == c2)){
                dfsVis(ele, c1, c2);
            }
            total_penalty += (penalty(abs(color[ele] - color[s])) * weight[s][ele] - total_weight[s][ele]);
            total_weight[s][ele] = penalty(abs(color[s] - color[ele])) * weight[s][ele];
            total_weight[ele][s] = penalty(abs(color[s] - color[ele])) * weight[ele][s];
        }
    }

    void dfs(int s, int c1, int c2){
        vis.clear();

        dfsVis(s, c1, c2);
    }

    void kempe(int u, int v, bool isHillClimbing){
        if(adj[u].find(v) == adj[u].end()) {
            // cout << "KEMPE input vertices " << u << "," << v << " are not adjacent\n";
            printf("KEMPE input vertices %d , %d are not adjacent\n", u, v);
            fflush(stdout);
            return;
        }

        track_subgraphs.clear();
        dfs(u, color[u], color[v]);

        if(isHillClimbing){
            vector<int> v (track_subgraphs.begin(), track_subgraphs.end());
            for(int i=0;i<v.size();i++){
                for(int j=i+1;j<v.size();j++){
                    kempe_done[v[i]][v[j]] = true;
                    kempe_done[v[j]][v[i]] = true;
                }
            }
        }
        track_subgraphs.clear();

        // cout << "After KEMPE at " << u << "," << v << ": " << calculate_total_penalty() << "\n";
        // printf("After KEMPE at %d, %d: %lf\n", u, v, calculate_total_penalty());
        // fflush(stdout);

    }

    void checker(){
        bool jhamela = false;
        for(int i=0;i<V;i++){
            int col = color[i];
            for(auto ele : adj[i]){
                if(color[ele] == col){
                    cout << "anomaly at coloring " << i << ", " << ele << "\n";
                    jhamela = true;
                }
            }
        }
        
        for(int i=0;i<student_courses.size();i++){
            unordered_map<int,bool,custom_hash> ump;
            for(auto ele : student_courses[i]){
                if(ump[color[ele]]){
                    cout << "problem detected\n";
                    jhamela = true;
                }
                ump[color[ele]] = true;
            }
        }

        if(!jhamela){
            cout << "No problems found\n";
        }
    }

    void crs_generator(){
        vector<int> crs(V);
        for(int i=0;i<student_courses.size();i++){
            for(auto ele : student_courses[i]){
                crs[ele]++;
            }
        }
        for(int i=0;i<V;i++){
            cout << setfill('0') << setw(4) << i + 1 << " " << crs[i] << "\n";
        }
    }
    
    void write_sol(string name){
        ofstream csol("outputs/" + name + ".sol");

        for(int i=0;i<V;i++){
            csol << i + 1 << " " << color[i] << "\n";
        }

        csol.close();
    }

    void Hill_climbing(){
        double cur_pen = calculate_total_penalty();
        int cnt = HILL_CLIMBING_COUNT;
        int n_stu = student_courses.size();

        vector<vector<int>> adj_vector;
        for(int i=0;i<V;i++){
            vector<int> v(adj[i].begin(), adj[i].end());
            adj_vector.push_back(v);
        }

        int no_of_kempe = 0;
        int real_kempe = 0;

        while(cnt--){
            // cout << cnt <<endl;
            int i = rand() % V;
            if(adj_vector[i].size() <= 1) {
                cnt++;
                continue;
            }
            int j = rand() % (int)adj[i].size();
            double pen = total_penalty;
            kempe(i, adj_vector[i][j], 0);
            total_kempe_count++;
            no_of_kempe++;
            // cout << "XKEMPE at " << i << "," << adj_vector[i][j] << ": " << total_penalty / n_stu << "\n";
            if(total_penalty >= pen){
                kempe(i, adj_vector[i][j], 0);
                total_kempe_count++;
                no_of_kempe++;
                // cout << "NKEMPE at " << i << "," << adj_vector[i][j] << ": " << total_penalty / n_stu << "\n";
            }else{
                real_kempe ++;
                cout << "KEMPE at " << i << "," << adj_vector[i][j] << ": " << total_penalty / n_stu << "\n";
                pen = total_penalty;
            }
        }
        // printf("Multi KEMPE ends\n");
        cout << "No. of kempes applied : " << no_of_kempe << "\n";
        cout << "No. of real kempes applied : " << real_kempe << "\n";
        cout << "Penalty : " << total_penalty / n_stu << endl;

    }

    pii find_min_penalt_kempe(){
        double mn = INF;
        int x = -1, y = -1;
        for(int i=0;i<V;i++){
            fill(kempe_done[i].begin(), kempe_done[i].end(), false);
        }
        int edge_cnt = 0;
        int cnt_kem = 0;
        for(int i=0;i<V;i++){
            edge_cnt += adj[i].size();
            for(auto ele : adj[i]){
                if(kempe_done[i][ele]) continue;
                kempe(i, ele, true);
                total_kempe_count++;
                cnt_kem++;
                // cout << "KEMPE at " << i << ", " << ele << ": " << total_penalty / n_stu << endl; 
                if(total_penalty < mn){
                    mn = total_penalty;
                    x = i;
                    y = ele;
                }
                kempe(i, ele, true);
                total_kempe_count++;
                // cout << "KEMPE at " << i << ", " << ele << ": " << total_penalty / n_stu << endl;
            }
        }
        cout << "Kempe count : " << cnt_kem << endl;
        cout << "Edge count : " << edge_cnt << endl;
        cout << "size of track_subgraphs: " << track_subgraphs.size() << endl;
        return {x, y};
    }

    void All_possible_kempe_min(){
        cout << calculate_total_penalty() << " " << n_stu << endl;
        int cnt = ALL_PAIR_COUNT;
        double mn = INF;
        int kem = 0;
        while(cnt--){
            pii p = find_min_penalt_kempe();
            if(p.first == -1) {
                cout << "Local minima reached\n";
                break;
            }
            kempe(p.first, p.second, false);
            total_kempe_count++;
            kem ++;
            cout << kem << ". MAIN KEMPE at " << p.first << ", " << p.second << ": " << total_penalty / n_stu << endl;
            if(mn > total_penalty){
                mn = total_penalty;
            }else{
                while(true){
                    int x = rand() % V;
                    if(adj[x].size() <= 1) continue;
                    int y = rand() % (int)adj[x].size();
                    vector<int> v(adj[x].begin(), adj[x].end());
                    kempe(x, v[y], false);
                    total_kempe_count++;
                    cout << kem << ". RANDOM KEMPE at " << x << ", " << v[y] << ": " << total_penalty / n_stu << endl;
                    break;
                }
            }
        }
        total_penalty = mn;
        cout << "MIn : " << mn / n_stu << endl;
        cout << "Total KEMPE : " << kem << endl;
    }

    // Constructive heuristics
    void largest_degree_heuristic(){
        vector<int> order = get_highest_degree_ordering();
        // cout << "order:\n";
        // printv(order);
        for(int i=0;i<order.size();i++){
            set<int> adj_colors;
            for(auto ele : adj[order[i]]){
                adj_colors.insert(color[ele]);
            }
            for(int j=0;j<V;j++){
                if(adj_colors.find(j) == adj_colors.end()){
                    color[order[i]] = j;
                    break;
                }
            }
        }
        
        // cout << "Slots : " << calculate_slots_cnt() << "\n";
    }

    void d_satur(){
        priority_queue<tuple<int,int,int>> pq;
        // pushing all now, as graph can be disconnected
        for(int i=0;i<V;i++){   
            pq.push({saturation[i], adj[i].size(), i});
        }
        int colored_count = 0;
        while(colored_count < V){
            int u = -1;
            while(true){
                u = get<2>(pq.top());
                if(color[u] != -1) pq.pop();
                else break;
            }
            if(u == -1) break;
            pq.pop();
            color[u] = MEX(u);
            for(auto ele : adj[u]){
                if(color[ele] == -1){
                    fix_saturation(ele);
                    pq.push({saturation[ele], adj[ele].size(), ele});
                }
            }
           
            // cout << u << " got " << color[u] << "\n";
            colored_count++;
        }
        // cout << "Slots : " << calculate_slots_cnt() << "\n";
    }

    void print_results(){
        // ofstream ofs("out.csv");
        ofs << input_name << "," << scheme_name << "," << calculate_slots_cnt() << "," << initial_penalty << "," << total_penalty  / n_stu << "," << total_time << "," << total_kempe_count << ",";
    }
};

void read_crs(Graph & g, string filename){
    ifstream fin("inputs/" + filename);
    string s;
    int cnt = 0;
    cout << "reading " << filename << ".crs";
    while(getline(fin, s)){
        cnt++;
    }
    g.init(cnt);
    fin.close();
}

void read_stu(Graph & g, string filename){
    ifstream fin("inputs/" + filename);
    string s;
    int cnt = 0;
    cout << "reading " << filename << ".stu";
    while(getline(fin, s)){
        s.push_back(' ');
        int n = s.size();
        string str;
        vector<int> courses;
        for(int i=0;i<n;i++){
            if(s[i] == ' '){
                if(!str.empty())
                    courses.push_back(stoi(str) - 1);
                str.clear();
            }else{
                if(s[i] != ' ')
                    str.push_back(s[i]);
            }
        }
        // printv(courses);

        for(int i=0;i<courses.size();i++){
            for(int j=i+1;j<courses.size();j++){
                g.addEdge(courses[i], courses[j]);
            }
        }
        g.add_student_with_courses(courses);
        cnt++;
    }
    // g.set_n_stu(cnt);
    fin.close();
}

void my_scheme_1(Graph & g){
    cout << "scheme1" << endl;
    auto start = high_resolution_clock::now();
    g.scheme_name = "Largest degree first and stochastic hill climbing";
    g.largest_degree_heuristic();
    g.initial_penalty = g.calculate_total_penalty();
    g.Hill_climbing();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    g.total_time = duration.count() / 1e6;
    g.print_results();
    g.write_sol(g.input_name);
}

void my_scheme_2(Graph & g){
    cout << "scheme2" << endl;
    auto start = high_resolution_clock::now();
    g.scheme_name = "Largest degree first and take minimum penalty out of all possible kempe and then a random move";
    g.largest_degree_heuristic();
    g.initial_penalty = g.calculate_total_penalty();
    g.All_possible_kempe_min();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    g.total_time = duration.count() / 1e6;
    g.print_results();
    g.write_sol(g.input_name);
}

void my_scheme_3(Graph & g){
    cout << "scheme3" << endl;
    auto start = high_resolution_clock::now();
    g.scheme_name = "Dsatur and stochastic hill climbing";
    g.d_satur();
    g.initial_penalty = g.calculate_total_penalty();
    g.Hill_climbing();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    g.total_time = duration.count() / 1e6;
    g.print_results();
    g.write_sol(g.input_name);
}

void my_scheme_4(Graph & g){
    cout << "scheme4" << endl;
    auto start = high_resolution_clock::now();
    g.scheme_name = "Dsatur and take minimum penalty out of all possible kempe and then a random move";
    g.d_satur();
    g.initial_penalty = g.calculate_total_penalty();
    g.All_possible_kempe_min();
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    g.total_time = duration.count() / 1e6;
    g.print_results();
    g.write_sol(g.input_name);
}


void solve(){
    ll n, m;

    string crs, stu;
    cin >> crs >> stu;
    
    cout << crs << endl;
    for(int i=0;i<4;i++){
        // cout << i << endl;
        Graph g = Graph(2);
        read_crs(g, crs);
        read_stu(g, stu);
        // cout << "\nread" << endl;
        g.input_name = crs.substr(0, 8);
        if(i == 0) my_scheme_1(g);
        else if(i == 1) my_scheme_2(g);
        else if(i == 2) my_scheme_3(g);
        else my_scheme_4(g);
        ofs << endl;
        cout << "***************************\n";
        
    }
    ofs << endl;
    
}

int main()
{
    // ios::sync_with_stdio(false);
    srand(time(0));
#ifndef ONLINE_JUDGE
    freopen("in", "r", stdin);
    freopen("out", "w", stdout);
#endif // ONLINE_JUDGE
    
    ofs << "Input name,Scheme,Slots,Intitial Penalty, Final Penalty, Total Time (sec.), Total Kempe Chains Discovered" << endl;
    auto start = high_resolution_clock::now();
    ll tt = 1;
    cin >> tt;
    ll cs = 1;
    while (tt--)
        solve();
    cout << tt << endl;
    auto stop = high_resolution_clock::now(); 
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "Time taken by function: " << duration.count() / 1e6 << " seconds" << endl; 
    ofs.close();
    return 0;
}